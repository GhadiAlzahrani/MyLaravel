@extends('layouts.app')

@section('content')

<style>
    body {
        background-color: #f8f9fa; /* Light blue background */
    }

    .card {
        border: none;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Subtle shadow */
        transition: box-shadow 0.3s ease; /* Smooth hover effect */
        
    }

    .card:hover {
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Slightly increased shadow on hover */
    }

    .card img {
        border-top-left-radius: 8px;
        border-bottom-left-radius: 8px;
        height: 150px; /* Adjusted image height */
        width: auto;
        object-fit: cover;
    }

    .card-body {
        padding: 15px; /* Reduced padding */
    }

    .card-title {
        font-size: 16px; /* Reduced font size */
        font-weight: bold;
        margin-bottom: 5px;
    }

    .card-description {
        font-size: 14px; /* Reduced font size */
        margin-bottom: 10px;
    }

    .price {
        font-size: 16px; /* Reduced font size */
        font-weight: bold;
    }

    .btn-show-details {
        background-color:#117bff; 
        color: #212529; /* Dark text color */
        border: none;
        border-radius: 5px;
        padding: 6px 12px; /* Reduced padding */
        font-weight: bold;
        transition: background-color 0.3s ease; /* Smooth transition */
    }

    .btn-show-details:hover {

        background-color: #003bff;; 
    }
</style>

<div class="container">
    <div class="row">
        <div class="col">

            @foreach($data as $items)
            <div class="card mb-3">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="/assets\images\{{$items->images}}" class="card-img" alt="Product Image">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h4 class="card-title">{{$items->ProductName}}</h4>
                            <p class="card-description">{{$items->Description}}</p>
                            <p class="price">{{$items->Price}} SAR</p>
                            <a href="/shopping/showdetails/{{$items->id}}" class="btn btn-show-details">Show Details >></a>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach

        </div>
    </div>
</div>

@endsection

@extends('layouts.base')

@section('content')
<div class="container">
    <div class="row mt-5">
        <div class="col">
            <div class="card bg-dark text-white">
                <div class="card-body">
                    <h1 class="text-center text-pink"><i class="bi bi-receipt-cutoff fs-3"></i></h1>
                    <h4 class="text-center">Invoice</h4>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="card bg-dark text-white">
                <div class="card-body">
                    <h1 class="text-center text-pink"><i class="bi bi-people fs-4"></i></h1>
                    <h4 class="text-center">Customers</h4>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="card bg-dark text-white">
                <div class="card-body">
                    <h1 class="text-center text-pink"><i class="bi bi-receipt-cutoff fs-3"></i></h1>
                    <h4 class="text-center">Invoice</h4>
                </div>
            </div>
        </div>
        <div class="col">
            <!-- Add your content here -->
        </div>
    </div>
</div>
@endsection

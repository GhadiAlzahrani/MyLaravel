@extends('layouts.app')

@section('content')
<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <h5 class="mb-4"><a href="shopping" class="text-body"><i class="bi bi-arrow-left me-2"></i>Continue shopping</a></h5>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th scope="col" style="width: 60%;">Product</th>
                            <th scope="col" style="width: 20%;">Price</th>
                            <th scope="col" style="width: 20%;">Quantity</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($data as $items)
                        <tr>
                            <td>
                                <div class="row align-items-center">
                                    <div class="col-md-4">
                                        <img src="/assets/images/{{$items->images}}" alt="Product Image" class="img-fluid">
                                    </div>
                                    <div class="col-md-8">
                                        <h6>{{$items->Description}}</h6>
                                    </div>
                                </div>
                            </td>
                            <td>{{$items->Price}} SAR</td>
                            <td>
                                <input type="number" class="form-control" value="1">
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
        <div class="row justify-content-left">
            <div class="col-md-4">
                <div class="card border-primary">
                    <div class="card-body">
                        <h5 class="card-title mb-4">Cart details</h5>
                        <hr>
                        
                        <div class="d-flex justify-content-between align-items-center">
                            <p class="mb-0">Total</p>
                            <p class="mb-0">{{$total_price}} SAR</p>
                        </div>
                        <div class="mt-4">
                            <button type="button" class="btn btn-primary btn-block">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span><i class="fas fa-check-circle me-2"></i>Checkout</span>
                                </div>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\support\Facades\Storage;
use Illuminate\Support\Facades\Http;



class TuwaiqController extends Controller
{
    //
    public function getHotCafe()
    {
      $response = Http::get('https://api.sampleapis.com/coffee/hot');
    }

   
    public function showTuwaiq()
    {
      
$jsondata=json_decode(Storage::get('public/data.json'));
return view('assignment2',['p'=>$jsondata]);

}
}
